# OmniAccess AI — Accessibility Chrome Extension

**AI-powered digital accessibility assistant for Chrome** that helps people with visual, hearing, motor, and cognitive disabilities interact with any web content through alternative input and output methods.

---

## 🚀 Features

### 🗣️ Voice-Controlled Navigation
- Say **"click login"**, **"scroll down"**, **"fill search with hello"**, **"go back"**
- Interactive numbered badge overlay: **"show numbers"** → **"click 4"**
- Continuous or push-to-talk recognition modes
- Real-time voice HUD with transcript display

### 🖼️ AI Image & Page Descriptions
- Describes charts, graphs, UI layouts, and memes aloud
- Powered by a **vision model on Groq** (Gemini and xAI Grok also supported) with offline heuristic fallback
- Auto-detects image type (chart/UI/meme/general) for contextual descriptions
- Click-to-describe mode for individual images
- Injects missing `alt` text and `aria-label` automatically

### 📖 Text Simplifier
- **3 reading levels**: Elementary (Grade 4), Plain English (Grade 8), Summary (bullet points)
- **Dyslexia-friendly fonts**: Lexend, Atkinson Hyperlegible, OpenDyslexic
- **Bionic Reading** mode (bold word-fixation points)
- **Read Aloud** with word-by-word highlighting, speed/pitch/voice control
- Flesch-Kincaid readability scoring
- Powered by OpenAI's GPT-OSS model on Groq (or Gemini / Grok) or a 100% offline heuristic engine

### ♿ WCAG 2.2 Auditor
- Checks: missing alt text, contrast < 4.5:1, missing form labels, heading hierarchy, vague links, unlabeled buttons, small touch targets (< 24px)
- **Auto-fix**: injects alt text, aria-labels, skip navigation links
- Visual report panel with severity colors (error/warning/notice)
- Click any issue to scroll-and-highlight the offending element

### 🎙️ Live Captions
- Real-time speech-to-text overlay for web video/audio
- Speaker change detection with **Speaker 1/2/3** labels
- Sound labels: **[Music]**, **[Laughter]**, **[Applause]**
- Draggable, resizable caption box
- Adjustable font size (small/medium/large)

### 🧭 Multimodal Input
| Input Method | Description |
|---|---|
| **Voice** | Web Speech API continuous recognition |
| **Gaze** | Webcam-based pupil tracking with dwell-click |
| **Switch Access** | Keyboard/button scanner with auto-scan |
| **Touch/Mouse** | Standard + large target mode |

### 🔊 Multimodal Output
| Output Method | Description |
|---|---|
| **Audio chimes** | Web Audio API sonification for all actions |
| **Read Aloud** | Word-highlighted SpeechSynthesis |
| **Live Captions** | Real-time speech-to-text overlay |
| **High Contrast** | Yellow-on-black, white-on-black themes |
| **Visual Alerts** | Screen flash for notifications |
| **Haptic feedback** | Vibration patterns on mobile |

### 🔒 Privacy-First
- **100% on-device processing** for gaze tracking, switch access, heuristic simplification
- AI provider API calls only happen when you configure an API key
- Webcam video is processed locally in Canvas memory — never uploaded
- Chrome Built-in AI (Prompt API) used when available for zero-network LLM
- Offline mode for all core features

---

## 📁 Project Structure

```
OmniAccess AI/
├── manifest.json                    # MV3 extension manifest
├── background/
│   └── service-worker.js            # Background service worker (settings, messaging)
├── content/
│   ├── content-main.js              # Main content script orchestrator
│   ├── voice-nav.js                 # Voice recognition & navigation engine
│   ├── gaze-tracker.js              # Webcam gaze & head gesture tracker
│   ├── live-captions.js             # Live speech-to-text captions
│   ├── switch-access.js             # Switch scanning engine
│   ├── wcag-auditor.js              # WCAG 2.2 accessibility checker
│   ├── read-aloud.js                # Word-highlighted read aloud engine
│   ├── image-describer.js           # AI vision image descriptions
│   ├── text-simplifier.js           # LLM + heuristic text simplification
│   ├── overlay.css                  # All injected UI styles
│   └── fonts.css                    # Dyslexia fonts & typography
├── sidepanel/
│   ├── index.html                   # Side panel main UI (WCAG AA)
│   ├── sidepanel.css                # Side panel styles (dark theme)
│   └── sidepanel.js                 # Side panel controller
├── shared/
│   ├── config.js                    # Default profiles & voice command dict
│   ├── gemini-api.js                # Groq / Gemini / Grok LLM & vision API integration
│   ├── heuristic-simplifier.js      # Offline-first text simplification
│   ├── audio-chimes.js              # Web Audio API sonification
│   └── storage-manager.js           # chrome.storage sync/local manager
├── icons/
│   ├── icon-16.png
│   ├── icon-48.png
│   └── icon-128.png
└── scripts/
    └── generate_icons.py            # Icon generation utility
```

---

## 🛠️ Installation & Live Demo

You can install the extension and test all features interactively via the official website:

👉 **[Launch OmniAccess AI Website & Install Guide](https://arnav-gc.github.io/Think-AI-4.0-Accessibility/)**

### Quick Install Steps:
1. Visit the website above or download [`omniaccess-ai-extension.zip`](omniaccess-ai-extension.zip) from this repository.
2. Unzip the downloaded file into a folder on your computer.
3. Open Google Chrome and go to `chrome://extensions/`.
4. Turn on **Developer mode** in the top right corner.
5. Click **Load unpacked** and select the unzipped folder.
6. Pin **OmniAccess AI** to your Chrome toolbar to begin!

---

## ⚙️ Configuration

### AI API Key (for AI features)
1. Get a free **Groq** API key at [console.groq.com](https://console.groq.com) (starts with `gsk_`)
2. Open OmniAccess AI side panel → **AI & Tools** tab
3. Choose **Groq (GPT-OSS)** as the provider, paste your key and click **Save Key**
4. Click **Test Key** to verify
5. Now text simplification uses `openai/gpt-oss-20b`, and image descriptions use Groq's vision model (`qwen/qwen3.8-27b`) because GPT-OSS is text-only

Google Gemini and xAI Grok are still available in the provider dropdown if you prefer them.

### Accessibility Profiles
Switch between preset profiles:
- **Low Vision** — high contrast + large cursor + zoom
- **Blind / Screen Reader** — voice nav + auto-describe images + audio chimes
- **Motor / Switch** — switch scanning + gaze + voice
- **Cognitive / Dyslexia** — Bionic Reading + Lexend font + text simplification
- **Deaf / Hard of Hearing** — live captions + sound labels + visual alerts
- **Custom** — mix and match any settings

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Alt + A` | Toggle floating dock |
| `Alt + V` | Toggle voice navigation |
| `Alt + R` | Read page aloud |
| `Alt + S` | Stop reading |

---

## 🎤 Voice Commands

| Say | Action |
|---|---|
| `"click [element]"` | Click button/link by name |
| `"scroll down"` / `"scroll up"` | Scroll page |
| `"show numbers"` | Show numbered markers |
| `"click 4"` | Click element #4 |
| `"fill search with hello"` | Fill form field |
| `"read page"` | Start read aloud |
| `"stop reading"` | Stop read aloud |
| `"audit page"` | Run WCAG audit |
| `"simplify text"` | Simplify page text |
| `"describe image"` | AI image descriptions |
| `"toggle contrast"` | Toggle high contrast |
| `"help"` | List all commands |

---

## 🧩 Technology Stack

| Feature | Technology |
|---|---|
| Speech recognition | Web Speech API (SpeechRecognition) |
| Text-to-speech | Web Speech API (SpeechSynthesis) |
| Image descriptions | Groq vision (qwen/qwen3.8-27b), or Gemini Vision |
| Text simplification | Groq GPT-OSS (openai/gpt-oss-20b), Gemini or Grok + Chrome Built-in AI (Prompt API) + Heuristic engine |
| Gaze tracking | Browser Canvas + WebGL pixel analysis (privacy-first) |
| Audio feedback | Web Audio API (no external files) |
| Storage | chrome.storage.sync + local (cross-device sync) |
| Extension | Manifest V3, Chrome APIs |

---

## 🔮 Roadmap

- [ ] MediaPipe Face Mesh integration for precise gaze tracking
- [ ] Whisper API alternative for speech recognition
- [ ] Page narration with positional audio cues
- [ ] Export accessibility audit report as PDF
- [ ] Multi-language voice command support
- [ ] Screen magnifier lens
- [ ] Color blindness simulation & correction filters

---

## 📜 License

MIT License — Built for the Think AI TCET Hackathon

---

*OmniAccess AI is itself built to be accessible: the extension UI follows WCAG 2.2 AA guidelines, all controls have proper labels, and the interface is fully keyboard-navigable.*
